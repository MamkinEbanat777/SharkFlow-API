// /api/auth/reset-password/confirm-reset
