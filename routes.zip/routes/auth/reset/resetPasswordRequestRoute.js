// /api/auth/reset-password/request
